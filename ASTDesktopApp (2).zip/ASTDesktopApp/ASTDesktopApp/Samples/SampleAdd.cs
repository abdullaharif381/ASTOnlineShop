﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;

namespace ASTDesktopApp
{
    public partial class SampleAdd : MaterialForm
    {
        public SampleAdd()
        {
            InitializeComponent();
        }

        private void materialLabel1_Click(object sender, EventArgs e)
        {

        }

        public virtual void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public virtual void SaveButton_Click(object sender, EventArgs e)
        {
            InitializeComponent();
        }
    }
}
